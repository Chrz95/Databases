import java.sql.*;
import java.util.InputMismatchException;
import java.util.Scanner;

public class DbApp {
	Connection conn;

	public DbApp() {
		conn = null;
	}	
	
	public void dbConnect (String ip, int port, String database, String username, String password) {
		try {
			// Check if postgres driver is loaded
     		Class.forName("org.postgresql.Driver");
     		// Establish connection with the database
     		conn = DriverManager.getConnection("jdbc:postgresql://"+ip+":"+port+"/"+database,username,password);
     		System.out.println("\nConnection Established!");
     		// Disable autocommit.
     		conn.setAutoCommit(false);
     		
		} catch(Exception e) {
            e.printStackTrace();
		}
	}
	
	public void db_commit() {
		try {
			// Commit all changes
			conn.commit();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void db_abort() {
		try {
			// Rollback all changes
			conn.rollback();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void showStudentGrade(long am , String course_code_param) {
		try {
			PreparedStatement pst = conn.prepareStatement("select final_grade  from \"Register\" where (\"Student_amka\" in (SELECT amka FROM \"Student\" WHERE am = ?) AND serial_number in (SELECT serial_number FROM \"CourseRun\" WHERE course_code = ?))") ;
			pst.setLong(1,am); 
			pst.setString(2,course_code_param);
			ResultSet rs = pst.executeQuery();  
			
			// Read results row by row
			System.out.println();
			while (rs.next()) {				
				System.out.println("The final grade of the student " + am + " at the lesson " + course_code_param + " is " + rs.getBigDecimal(1));
			}
			
			pst.close();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}		
	}
	
	public void showAllStudentGrades (long am) {
		try {
														 
			PreparedStatement pst = conn.prepareStatement("select final_grade , course_code from \"Register\" R , \"CourseRun\" CR where (\"Student_amka\" in (SELECT amka FROM \"Student\" WHERE am = ?) AND CR.serial_number = R.serial_number)") ;
			pst.setLong(1,am); 
			ResultSet rs = pst.executeQuery();  
			
			// Read results row by row
			System.out.println("\nThe grades of the student "+ am +" are :\n");
			System.out.println("Lesson  | Final Grade");
			
			while (rs.next()) {				
				System.out.println(rs.getString(2)+" | "+rs.getBigDecimal(1));
			}
			
			pst.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}		
	}
	
	public void searchPerson (String surname_initials) {
		try {
			PreparedStatement pst = conn.prepareStatement("SELECT * FROM ((SELECT name , surname , amka , 'Student' FROM \"Student\") UNION (SELECT  name , surname , amka ,  'Professor'	FROM \"Professor\") UNION (SELECT  name , surname , amka ,  'Labstaff' FROM \"Labstaff\")) as people WHERE left(people.surname,?) = ? ") ;
						
			pst.setInt(1,surname_initials.length());
			pst.setString(2,surname_initials); 			
			ResultSet rs = pst.executeQuery();					
			
			// Read results row by row
			System.out.println("\nThe university members with " + surname_initials + " are : \n" );
			System.out.println("Name | Surname | Amka | Position");
			while (rs.next()) {
				// Read values of columns in row
				System.out.println(rs.getString(1)+"|"+rs.getString(2)+"|"+rs.getString(3)+"|"+rs.getString(4));
			}
			
			pst.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}		
	}
	
	public void changeGrade (long am , String course_code_param,int serial_number_param ,float final_grade_param ) {
		try {
			
			PreparedStatement  pst = conn.prepareStatement("UPDATE \"Register\" SET final_grade = ? WHERE \"Student_amka\" = (SELECT amka FROM \"Student\" WHERE am = ?) AND serial_number = ? AND serial_number in (SELECT serial_number FROM \"CourseRun\" WHERE course_code = ?)");
			pst.setFloat(1,final_grade_param);
			pst.setLong(2,am);
			pst.setInt(3,serial_number_param);
			pst.setString(4,course_code_param);		
			pst.executeUpdate();
			pst.close();
			} catch (SQLException e) {
			e.printStackTrace();
		}		
	}
	
	public void insertDiploma(long am,int supervisor,int committee_1,int committee_2,String title ) {
		try {
			// Create a SQL query template with parameters
			CallableStatement cst = conn.prepareCall("{call diploma_input_1_4(?,?,?,?,?)}");
		    cst.setLong(1,am);
		    cst.setInt(2,supervisor);
		    cst.setInt(3,committee_1);
		    cst.setInt(4,committee_2);
		    cst.setString(5,title);
		    cst.executeUpdate(); 
		    cst.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}				
	}

	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
		int choice ; 
		DbApp db = new DbApp();
		
		System.out.println ("Database connection ... ") ; 
		System.out.println ("\nInsert host,database name,username,password (Press Enter after each entry!) : \n") ; 
     	db.dbConnect(scanner.next(),5432,scanner.next(),scanner.next(),scanner.next());
		
		while (true){					
			
			System.out.println ("\nDatabase connection menu : \n") ; 
			
			System.out.println ("1.Commit transaction") ; 
			System.out.println ("2.Abort transaction") ;
			System.out.println ("3.Insert diploma") ; 
			System.out.println ("4.Student grade at a lesson") ; 
			System.out.println ("5.Change student grade at a lesson") ; 
			System.out.println ("6.Search person") ; 
			System.out.println ("7.Full student grades") ;
			System.out.println ("8.Exit software\n") ;
			
			System.out.print ("Choose one of the above , by entering the respective number : ") ;
			
			try 
			{
				choice = scanner.nextInt() ;}
			catch (InputMismatchException e)
			{
				System.out.println ("Invalid choice ! Please enter an integer!") ;
				break; 
			} ;
			
			
		     switch (choice) {
	            case 1: 
	            		db.db_commit();
	            		System.out.println ("�ranscation commited!") ;		
	                    break;
	            case 2: 
	            	    db.db_abort();
	            	    System.out.println ("�ranscation aborted!") ;	
	                    break;	            		
	            case 3:
		            	System.out.println ("Insert AM , Supervisor Amka , Committee 1 Amka , Committee 2 Amka , Title. (Press Enter after each entry!) : \n") ;
	            		db.insertDiploma(scanner.nextLong(),scanner.nextInt(),scanner.nextInt(),scanner.nextInt(),scanner.next());
	            	    break;
	            case 4:
		            	System.out.println ("Insert AM , Course Code. (Press Enter after each entry!) : \n") ;
	            	    db.showStudentGrade(scanner.nextLong(),scanner.next() +" "+scanner.nextInt());
	                    break;
	            case 5:
		            	System.out.println ("Insert AM , Course Code , serial number , final grade. (Press Enter after each entry!) : \n") ;
	            		db.changeGrade (scanner.nextLong() ,scanner.next() +" "+scanner.nextInt(),scanner.nextInt() ,scanner.nextFloat()) ;
	                    break;
	            case 6:
		            	System.out.println ("Insert Surname initials. (Press Enter after each entry!) : \n") ;
	            	    db.searchPerson (scanner.next());
	                    break;
	            case 7:  
		            	System.out.println ("Insert ��. (Press Enter after each entry!) : \n") ;
		            	db.showAllStudentGrades (scanner.nextLong());
	                    break;
	            case 8:    
	            	    System.out.println ("You have closed the software!") ;
            			scanner.close() ; 
            			System.exit(0);
            			break; 	
	            default: 
	            	    System.out.println ("Invalid choice! Please enter an integer from 1 to 8!") ;
	                    break;
	        }		
			
		}
		
	
		
	}
}
